================================================================
  THE STASH - STASH COMPANION
  Zero Telemetry • 100% Local Sandbox
================================================================

FEATURES:
- Clarify: Real-ESRGAN AI Super-Resolution (Vulkan GPU)
- FetchFlow: yt-dlp 4K & MP3 320k media downloader

HOW TO RUN:
Option 1: Double-click "StashCompanion.exe" (No Python required).
Option 2: Double-click "start_companion.bat" (Runs via Python).

Open "the stash" hub in your browser (https://theaser7.github.io).
All downloaded media files are saved to:
  Downloads/the_stash/
================================================================
