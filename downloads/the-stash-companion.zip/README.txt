================================================================
  THE STASH - UNIFIED COMPANION SERVER
  Zero Telemetry • 100% Local Sandbox
================================================================

Hardware Acceleration:
- Clarify: Real-ESRGAN Vulkan GPU (RTX 4060 / Vulkan)
- FetchFlow: yt-dlp multi-stream 4K & MP3 320k (Ryzen 5)

HOW TO RUN:
1. Make sure Python 3.9+ is installed (https://python.org).
2. Double-click "start_companion.bat".
3. Open "the stash" hub in your browser (https://theaser7.github.io).
4. Enjoy local GPU AI upscaling and full-speed 4K/MP3 media downloads!

All downloaded files are automatically saved to:
  Downloads/the_stash/
================================================================
