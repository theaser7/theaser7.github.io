THE STASH COMPANION SERVER
===========================
Zero Telemetry - 100% Local Hardware Acceleration Backend

HOW TO RUN:
Option 1: Double-click StashCompanion.exe
Option 2: Double-click start_companion.bat (requires Python 3.9+)

Once running on port 7860, reload the web app (Clarify / FetchFlow) and the server status indicator will turn green!
